const db = require("../models");
const User = db.users;
//saving user into mongodb
exports.create = (req, res ) => {
    const user = new User({
        email: req.body.email,
        password: req.body.password
    });

    user
        .save(user)
        .then(data => res.send(data))
        .catch(err => {
            res.status(500).send({
                msg:
                    err.msg || "Error while creating User"
            });
        });
};

exports.findAll = (req,res) => {
    User.find()
            .then(data => {
                res.send(data);
            })
            .catch(err => {
                res.status(500).send({
                    msg:
                        err.msg || "Error while retrieving User"
                });
            });
}

